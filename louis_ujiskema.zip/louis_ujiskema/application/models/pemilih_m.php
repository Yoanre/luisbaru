<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pemilih_m extends CI_Model {
    public function login($post){
        $this->db->select('*');
        $this->db->from('pemilih');
        $this->db->where('username', $post['username']);
        $this->db->where('password', sha1($post['password']));
        $query = $this->db->get();
        return $query;
    }

    public function getData(){
        return $this->db->get('pemilih')->result_array();
    }

    public function tambahPemilih(){
        $data=[
            'username' => $this->input->post('username', true),
            'nama' => $this->input->post('nama', true),
            'password' => sha1($this->input->post('password', true)),
            'nisn' => $this->input->post('nisn', true),
            'alamat' => $this->input->post('alamat', true)
        ];

        $this->db->insert('pemilih', $data);
    }

    public function getPemilihById($id)
    {
        return $this->db->get_where('pemilih', ['id_pemilih' => $id])->row_array();
    }
    public function editPemilih()
    {
        $data = [
            'username' => $this->input->post('username', true),
            'nama' => $this->input->post('nama', true),
            'password' => sha1($this->input->post('password', true)),
            'nisn' => $this->input->post('nisn', true),
            'alamat' => $this->input->post('alamat', true)
        ];

        $this->db->where('id_pemilih', $this->input->post('id_pemilih'));
        $this->db->update('pemilih', $data);
    }

    public function hapusPemilih($id){
        $this->db->where('id_pemilih', $id);
        $this->db->delete('pemilih');
    }

    public function getId($id){
        return $this->db->get_where('kandidat', ['id_kandidat' => $id])->row_array();
    }

    public function vote($insert)
    {
        $this->db->insert('hasil', $insert);
    }
    public function cek()
    {
        return $this->db->get_where('hasil', ['id_pemilih' => $_SESSION['id_pemilih']])->num_rows();
    }
}