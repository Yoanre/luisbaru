<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kandidat_m extends CI_Model {

    public function getData(){
        return $this->db->get('kandidat')->result_array();
    }

    public function tambahKandidat(){
        $data=[
            'nama_ketos' => $this->input->post('nama_ketos', true),
            'nama_waketos' => $this->input->post('nama_waketos', true),
            'image' => $this->input->post('image', true),
            'visi' => $this->input->post('visi', true),
            'misi' => $this->input->post('misi', true)
        ];

        $this->db->insert('kandidat', $data);
    }

    public function getKandidatById($id)
    {
        return $this->db->get_where('kandidat', ['id_kandidat' => $id])->row_array();
    }
    public function editKandidat()
    {
        $data = [
            'nama_ketos' => $this->input->post('nama_ketos', true),
            'nama_waketos' => $this->input->post('nama_waketos', true),
            'image' => $this->input->post('image', true),
            'visi' => $this->input->post('visi', true),
            'misi' => $this->input->post('misi', true)
        ];

        $this->db->where('id_kandidat', $this->input->post('id_kandidat'));
        $this->db->update('kandidat', $data);
    }

    public function hapusKandidat($id){
        $this->db->where('id_kandidat', $id);
        $this->db->delete('kandidat');
    }

    public function getId($id){
        return $this->db->get_where('kandidat', ['id_kandidat' => $id])->row_array();
    }
}