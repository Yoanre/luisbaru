<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin_m extends CI_Model {
    public function login($post){
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('username', $post['username']);
        $this->db->where('password', sha1($post['password']));
        $query = $this->db->get();
        return $query;
    }

    public function getData(){
        return $this->db->get('user')->result_array();
    }

    public function tambahAdmin(){
        $data=[
            'username' => $this->input->post('username', true),
            'email' => $this->input->post('email', true),
            'password' => sha1($this->input->post('password', true))
        ];

        $this->db->insert('user', $data);
    }

    public function getAdminById($id)
    {
        return $this->db->get_where('user', ['id_user' => $id])->row_array();
    }
    public function editAdmin()
    {
        $data = [
            "username" => $this->input->post('username', true),
            "email" => $this->input->post('email', true),
            'password' => sha1($this->input->post('password', true))
        ];

        $this->db->where('id_user', $this->input->post('id_user'));
        $this->db->update('user', $data);
    }

    public function hapusAdmin($id){
        $this->db->where('id_user', $id);
        $this->db->delete('user');
    }
}