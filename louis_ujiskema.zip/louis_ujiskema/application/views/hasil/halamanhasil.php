<div class="container mt-5">
<div class="card mt-3">
  <div class="card-header">
  <div class="d-flex justify-content-between">
      HASIL VOTING
    </div>
  </div>
  <div class="container">

    <div class="card-body">
      <div class="row">
        <div class="card">
          <table class="table table-hover table-bordered table-striped">
            <thead class="table-dark">
              <tr>
                <th scope="col">id</th>
                <th scope="col">Nama Kandidat</th>
                <th scope="col">Nama Pemilih</th>
                <th scope="col">Tanggal / Jam</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; ?>
              <?php foreach ($hasil as $hsl) : ?>
                <tr>
                  <th scope="row"><?= $no++; ?></th>
                  <td><?= $hsl['nama_ketos'] ?></td>
                  <td><?= $hsl['nama'] ?></td>
                  <td><?= $hsl['tanggal_jam'] ?></td>
                  <td>
                    <a href="<?= base_url('hasil/hapus/') ?><?= $hsl['id_hasil'] ?>" class="btn btn-danger">Hapus</a>
                    <a href="<?= base_url('hasil/detail/') ?><?= $hsl['id_hasil'] ?>" class="btn btn-warning">Detail</a>
                  </td>
                </tr>
                <?php $no++ ?>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>