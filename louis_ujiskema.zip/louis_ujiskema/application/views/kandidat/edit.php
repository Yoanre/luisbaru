<h1 class="d-flex justify-content-center mt-5">Halaman Edit Kandidat</h1>
<div class="tambah d-flex justify-content-center mt-5">
    <div class="card" style="width: 50%;">
        <div class="container my-5">
            <form action="kandidat/edit" method="POST">

            <input type="hidden" name="id_kandidat" value="<?= $kandidat['id_kandidat'] ?>">

                <div class="mb-3">
                    <label class="form-label">Ketos</label>
                    <input type="text" name="nama_ketos" class="form-control" id="nama_ketos" value="<?= $kandidat['nama_ketos'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Waketos</label>
                    <input type="text" name="nama_waketos" class="form-control" id="nama_waketos" value="<?= $kandidat['nama_waketos'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Image</label>
                    <input type="text" name="image" class="form-control" id="image" value="<?= $kandidat['image'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Visi</label>
                    <input type="text" name="visi" class="form-control" id="visi" value="<?= $kandidat['visi'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Misi</label>
                    <input type="text" name="misi" class="form-control" id="misi" value="<?= $kandidat['misi'] ?>">
                </div>
                <button href="<?=base_url();?> kandidat" type="submit" name="edit" class="btn btn-warning">Edit</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </form>
        </div>
    </div>
</div>