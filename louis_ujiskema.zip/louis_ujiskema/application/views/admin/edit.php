<h1 class="d-flex justify-content-center mt-5">Halaman Edit Admin</h1>
<div class="tambah d-flex justify-content-center mt-5">
    <div class="card" style="width: 50%;">
        <div class="container my-5">
            <form action="admin/edit" method="POST">

            <input type="hidden" name="id_user" value="<?= $user['id_user'] ?>">

                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" id="username" value="<?= $user['username'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">E-mail</label>
                    <input type="text" name="email" class="form-control" id="email" value="<?= $user['email'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="text" name="password" class="form-control" id="password" value="<?= $user['password'] ?>">
                </div>
                <button href="<?=base_url();?> admin" type="submit" name="edit" class="btn btn-warning">Edit</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </form>
        </div>
    </div>
</div>