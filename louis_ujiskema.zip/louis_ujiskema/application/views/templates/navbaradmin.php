<nav class="navbar navbar-light" style="height: 70px; background-color: #A9A9A9;">
  <div class="container-sm">
    <a class="navbar-brand">APPS E-VOTING</a>
    <form class="d-flex">
      <div class="d-grid gap-2 d-md-block">
        <a href="<?= base_url('kandidat') ?>" class="btn btn-outline-primary">Kandidat</a>
        <a href="<?= base_url('admin') ?>" class="btn btn-outline-primary">Admin</a>
        <a href="<?= base_url('adminpemilih') ?>" class="btn btn-outline-primary">Pemilih</a>
        <a href=" <?= base_url('hasil') ?>" class="btn btn-outline-primary">Hasil</a>
        <a href="<?= base_url('loginadmin/logout') ?>" class="btn btn-outline-danger">Logout</a>
      </div>
    </form>
  </div>

</nav>