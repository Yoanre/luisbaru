<nav class="navbar navbar-light" style="height: 70px; background-color: #A9A9A9;">
  <div class="container-sm">
    <a class="navbar-brand">APPS E-VOTING</a>
  </div>
</nav>