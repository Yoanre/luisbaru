<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class adminpemilih extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('pemilih_m');
    }

    public function index(){
        $data['pemilih'] = $this->pemilih_m->getData();

        $this->load->view('templates/header');
        $this->load->view('templates/navbaradmin');
        $this->load->view('pemilih/halamanadminpemilih', $data);
    }

    public function tambah(){
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('nisn', 'Nisn', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header');
            $this->load->view('pemilih/tambah');
        }else{
            $this->pemilih_m->tambahPemilih();
            redirect('adminpemilih');
        }
    }

    public function edit($id)
    {
        $data['pemilih'] = $this->pemilih_m->getPemilihById($id);
       
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('nisn', 'Nisn', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header');
            $this->load->view('pemilih/edit', $data);
        }else{
            $this->pemilih_m->editPemilih();
            redirect('adminpemilih');
        }
    }

    public function hapus($id){
        $this->pemilih_m->hapusPemilih($id);
        redirect('adminpemilih');
    }
}