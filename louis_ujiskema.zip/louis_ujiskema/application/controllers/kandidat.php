<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kandidat extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('kandidat_m');
    }

    public function index(){
        $data['kandidat'] = $this->kandidat_m->getData();

        $this->load->view('templates/header');
        $this->load->view('templates/navbaradmin');
        $this->load->view('kandidat/halamankandidat', $data);
    }

    public function tambah(){
        $this->form_validation->set_rules('nama_ketos', 'NamaKetos', 'required');
        $this->form_validation->set_rules('nama_waketos', 'Nama Waketos', 'required');
        $this->form_validation->set_rules('image', 'Image', 'required');
        $this->form_validation->set_rules('visi', 'Visi', 'required');
        $this->form_validation->set_rules('misi', 'Misi', 'required');

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header');
            $this->load->view('kandidat/tambah');
        }else{
            $this->kandidat_m->tambahKandidat();
            redirect('kandidat');
        }
    }

    public function edit($id)
    {
        $data['kandidat'] = $this->kandidat_m->getKandidatById($id);
       
        $this->form_validation->set_rules('nama_ketos', 'NamaKetos', 'required');
        $this->form_validation->set_rules('nama_waketos', 'Nama Waketos', 'required');
        $this->form_validation->set_rules('image', 'Image', 'required');
        $this->form_validation->set_rules('visi', 'Visi', 'required');
        $this->form_validation->set_rules('misi', 'Misi', 'required');

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header');
            $this->load->view('kandidat/edit', $data);
        }else{
            $this->kandidat_m->editKandidat();
            redirect('kandidat');
        }
    }

    public function hapus($id){
        $this->kandidat_m->hapusKandidat($id);
        redirect('kandidat');
    }

    public function detail($id)
    {
        $data['kandidat'] = $this->kandidat_m->getId($id);

        $this->load->view('templates/header');
        $this->load->view('kandidat/detail', $data);
    }
}