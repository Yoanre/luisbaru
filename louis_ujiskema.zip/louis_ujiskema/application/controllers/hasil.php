<?php
defined('BASEPATH') or exit('No direct script access allowed');

class hasil extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('hasil_m');
    }

    public function index()
    {
        $data['hasil'] = $this->hasil_m->getData();

        $this->load->view('templates/header');
        $this->load->view('templates/navbaradmin');
        $this->load->view('hasil/halamanhasil', $data);
    }

    public function detail($id)
    {
        $data['hasil'] = $this->hasil_m->getId($id);

        $this->load->view('templates/header');
        $this->load->view('hasil/detail', $data);
    }

    public function hapus($id){
        $this->hasil_m->hapus($id);
        redirect('hasil');
    }

    public function selamat()
    {
        // $this->load->view('template/header');
        // $this->load->view('hasil/selamat');
        // $this->load->view('template/footer');

        redirect('login/logout');
    }

}